from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import os
import sys

HOST = "127.0.0.1"
PORT = 13000
T_INDEX_PATH = '/server/templates/index.html'

def load_template(_path):
    try:
        with open(_path, 'r') as f:
            data = f.read()
    except Exception as e:
        data = e
    
    return data


def show_result(_cmd=''):
    try:
        output = os.popen(_cmd).read()
        output = output.replace("\n", "<br>")
    except Exception as e:
        output = ''
        
    html = load_template(T_INDEX_PATH)
    html = html.replace("{{result}}", output)

    return html

class BackendHttpRequestHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        html = ''
        self.send_response(200, "OK")
        self.send_header("Content-type", "text/html")
        self.end_headers()

        param = urlparse(self.path).query
        cmd = parse_qs(param)

        if not cmd:
            html = show_result()
        else:
            html = show_result(cmd['cmd'][0])
                    
        self.wfile.write(bytes(html, "utf-8"))


if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), BackendHttpRequestHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
        sys.exit(0)