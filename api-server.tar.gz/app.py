from flask import Flask, request, render_template, make_response
import requests

app = Flask(__name__)

T_INDEX_HTML = "index.html"

def get_url_content(_url):
    try:
        data = requests.get(_url).content.decode()
    except Exception as e:
        print(e)
        data = "NOT FOUND"
    
    return data

@app.route('/', methods=['GET', 'POST'])
def index():
    data = ""
    url = "http://example.com"
    if request.method == 'GET':
        data = get_url_content(url)
        return render_template(T_INDEX_HTML, web_content=data)

    url = request.form.get('url', '')
    data = get_url_content(url)

    resp = make_response(render_template(T_INDEX_HTML, web_content=data))

    return resp


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)